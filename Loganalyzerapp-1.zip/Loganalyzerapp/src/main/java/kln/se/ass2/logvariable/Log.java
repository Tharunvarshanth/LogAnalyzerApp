package kln.se.ass2.logvariable;

public interface Log {
    String getTimestatmp();
    void setTimestatmp(String timestatmp);
    String getLoglevel();
    void setLoglevel(String loglevel);
}
