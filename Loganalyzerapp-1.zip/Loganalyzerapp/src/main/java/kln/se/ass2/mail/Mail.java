package kln.se.ass2.mail;

public interface Mail {
    void sendmail();
}
