package kln.se.ass2.input;

public interface Input {
    String readFilepath();
}
