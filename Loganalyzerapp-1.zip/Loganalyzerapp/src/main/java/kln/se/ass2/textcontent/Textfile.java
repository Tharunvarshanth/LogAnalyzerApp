package kln.se.ass2.textcontent;

import java.io.File;

public interface Textfile {
    public static String filepath ="src\\main\\resources\\text.txt";

    static File textfile = new File(filepath);
}
